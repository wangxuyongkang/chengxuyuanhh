# 课程介绍

学习javascript中条件判断语句、循环语句、数组及数组操作、字符串及字符串操作、javascript的组成javascript调试方法，javascript定时器的操作。