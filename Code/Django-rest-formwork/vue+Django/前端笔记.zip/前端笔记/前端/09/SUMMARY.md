# Summary

* [课程介绍](README.md)
* [JavaScript介绍](mds/section00.md)
* [JavaScript嵌入页面的方式](mds/section01.md)
* [变量](mds/section02.md)
* [获取元素方法一](mds/section03.md)
* [操作元素属性](mds/section04.md)
* [函数](mds/section05.md)
